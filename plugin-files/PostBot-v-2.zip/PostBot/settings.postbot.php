<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
die("Hi there! I'm just a plugin, not much I can do when called directly.");
exit();
};

function PostBot_static ( $hook)
    {
        global $PostBotMenu, $PostBotSubMenu;
        $allowed = array( $PostBotMenu, $PostBotSubMenu);
        if( !in_array( $hook, $allowed)  )
        {
            return;
        }
        wp_enqueue_style( 'postbot', plugin_dir_url(__FILE__) . '/static/style.css', array(), '1.0.0', 'all' );
        
        wp_enqueue_script( 'postbot', plugins_url( '/static/script.js' , __FILE__ ), array(), '1.0.0', '' );
    }
    
    add_action( 'admin_enqueue_scripts', 'PostBot_static');
    
    function postbot_settings ()  {
    global $wpdb;
    echo '<h2>PostBot</h2>';
    echo '<div class="postbot-subtitle">Follow these introductory steps to get started with PostBot.</div>';
    echo '<br><br>';
    echo '<div class="postbot">';
    echo '<div class="postbot-row">';
    echo '<div class="postbot-col-75">';
    echo '<div class="postbot-container">';
    echo '<h3>Add New Feed Source</h3>';
    postbot_add_item();
    echo '<form action="" method="post">';
    echo '<div class="postbot-row">';
    echo '<div class="postbot-col-50">';
    echo '<br>';
    echo '<label for="postbot_author">Author</label>';
    echo '<select name="postbot_author" required>';
    $postbot_all_users = get_users();
    foreach ($postbot_all_users as $postbot_user) {
            echo  '<option value="'.$postbot_user->ID.'">'.$postbot_user->display_name.'</option>';
    }
    echo '</select>';
    echo '<label for="postbot-cron">Update interval <a class="postbot-tooltip fa fa-question-circle" href="#postbot-interval"></a></label>';
    echo '<select name="postbot_cron" required>';
    $cron_array = array('300'=>'every 5min', '1800'=>'every 30mins', '3600'=>'every 1hour', '86400'=>'every 24hours', '0'=>'Never');
    foreach($cron_array as $postbot_cron_id => $postbot_cron) {
        echo  '<option value="'.$postbot_cron_id.'">'.$postbot_cron.'</option>';
    }
    echo '</select>';
    echo '<label for="postbot-cat">Category</label>';
    echo '<select name="postbot_categories" required>';
    $postbot_categories = get_categories( array('orderby' => 'name', 'order' => 'ASC', 'hide_empty' =>0) );
    foreach ($postbot_categories as $postbot_category ) {
        echo  '<option value="'.$postbot_category->term_id.'">'.$postbot_category->name.'</option>';
    }
    echo '</select>';
    echo '<label>';
    echo '<input type="checkbox" checked="checked" value="Yes" name="postbot_remove_credits"> Remove Post-credits';
    echo '&nbsp;&nbsp;<a data-postbot-react="true" class="postbot-tooltip fa fa-question-circle" href="#postbot-credits"></a>';
    echo '</label>';
    echo '<label>';
    echo '<input type="checkbox" checked="checked" value="Yes" name="postbot_remove_links"> Remove external URL';
    echo '&nbsp;&nbsp;<a data-postbot-react="true" class="postbot-tooltip fa fa-question-circle" href="#postbot-external-url"></a>';
    echo '</label>';
    echo '<label>';
    echo '<input type="checkbox" checked="checked" value="Yes" name="postbot_nofollow"> Nofollow external URL';
    echo '&nbsp;&nbsp;<a data-postbot-react="true" class="postbot-tooltip fa fa-question-circle" href="#postbot-nofollow"></a>';
    echo '</label>';
    echo '<br>';
    echo '<input type="submit" name="postbot_submit" value="Publish">';
    echo '</div>';
    echo '<div class="postbot-col-50">';
    echo '<br>';
    echo '<label for="postbot_title">Title</label>';
    echo '<input type="text" name="postbot_title" autocomplete="off" id="postbot_title" placeholder="Name this feed">';
    echo '&nbsp;&nbsp;<a data-postbot-react="true" class="postbot-tooltip fa fa-question-circle" href="#postbot-title"></a>';
    echo '<label for="postbot-url">URL or <a data-postbot-react="true" href="#postbot-youtube-channel-id">Youtube Channel URL</a></label>';
    echo '<input type="text" autocomplete="off" name="postbot_url" id="postbot-url" placeholder="Enter an RSS Feed or any website URL.">';
    echo '&nbsp;&nbsp;<a data-postbot-react="true" class="postbot-tooltip fa fa-question-circle" href="#postbot-url"></a>';
    echo '<label for="rules"><a href="#postbot-rules">Page Rules</a> (If the URL matches)</label>';
    echo '<input type="text" id="rules" autocomplete="off" placeholder="Enter pattern URL" name="postbot_rules">';
    echo '&nbsp;&nbsp;<a data-postbot-react="true" class="postbot-tooltip fa fa-question-circle" href="#postbot-rules"></a>';
    echo '<label for="postbot-limit">Limit</label>';
    echo '<input type="number" autocomplete="off" value="20" name="postbot_limit" id="postbot-limit" placeholder="">';
    echo '&nbsp;&nbsp;<a data-postbot-react="true" class="postbot-tooltip fa fa-question-circle" href="#postbot-limit"></a>';
    echo '<label>';
    echo '<input type="checkbox" value="Yes" name="postbot_spin"> Rewrite article';
    echo '</label>';  
    echo '<label>';
    echo '<input type="checkbox" checked="checked" value="Yes" name="postbot_content"> Full Content';
    echo '&nbsp;&nbsp;<a data-postbot-react="true" class="postbot-tooltip fa fa-question-circle" href="#postbot-full-content"></a>';
    echo '</label>';
    echo '<label>';
    echo '<input type="checkbox" checked="checked" value="Yes" name="postbot_source"> Add Source';
    echo '&nbsp;&nbsp;<a data-postbot-react="true" class="postbot-tooltip fa fa-question-circle" href="#postbot-add-source"></a>';
    echo '</label>';
    echo '<label>';
    echo '<input type="checkbox" checked="checked" value="Yes" name="postbot_add_video_description"> Add Youtube Video description';
    echo '&nbsp;&nbsp;<a data-postbot-react="true" class="postbot-tooltip fa fa-question-circle" href="#postbot_add_video_description"></a>';
    echo '</label>';
    echo '<br>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo  '<div class="postbot-col-25">';
    echo '<div class="postbot-container">';
    require_once('faq.postbot.php');
    echo '</div>';
    echo '</div>';
    }
    
    function postbot_add_item () {
    global $wpdb;
    $postbot_insert = false;
    $postbot_url = '';
    $postbot_errors = array();
    if (isset($_POST['postbot_submit'])) {
    if(isset($_POST['postbot_url'])) {
        $postbot_url = sanitize_text_field($_POST['postbot_url']);
        if (!filter_var(trim($postbot_url), FILTER_VALIDATE_URL)) {
            $postbot_errors[] = 'Feed Source URL is not valid.';
        }
    }
        $postbot_title = sanitize_text_field($_POST['postbot_title']);
        if(empty($postbot_title)) {
            $postbot_errors[] = 'Feed title is required';
        }
        $postbot_cron = sanitize_text_field($_POST['postbot_cron']);
        $postbot_categories = sanitize_text_field($_POST['postbot_categories']);
        $postbot_remove_credits = sanitize_text_field($_POST['postbot_remove_credits']);
        $postbot_remove_links = sanitize_text_field($_POST['postbot_remove_links']);
        $postbot_nofollow = sanitize_text_field($_POST['postbot_nofollow']);
        $postbot_spin = sanitize_text_field($_POST['postbot_spin']);
        $postbot_limit = sanitize_text_field($_POST['postbot_limit']);
        $postbot_rules = sanitize_text_field($_POST['postbot_rules']);
        $postbot_author = sanitize_text_field($_POST['postbot_author']);
        $postbot_content = sanitize_text_field($_POST['postbot_content']);
        $postbot_add_video_description = sanitize_text_field($_POST['postbot_add_video_description']);
        if(empty($postbot_errors)) {
        $postbot_insert = array(
            'post_title' => $postbot_title,
            'post_status' => 'publish',
            'post_type' => 'postbot',
            'meta_input' => array(
                'postbot_url' => $postbot_url,
                'postbot_interval' => $postbot_cron,
                'postbot_category_id'=>$postbot_categories,
                'postbot_remove_credits'=>$postbot_remove_credits,
                'postbot_remove_external_links'=>$postbot_remove_links,
                'postbot_nofollow'=>$postbot_nofollow,
                'article_rewriter'=>$postbot_spin,
                'postbot_limit'=>$postbot_limit,
                'postbot_rules'=>$postbot_rules,
                'postbot_author_id'=>$postbot_author,
                'postbot_full_content'=>$postbot_content,
                'postbot_updated'=>date( 'Y-m-d H:i:s', time()),
                'postbot_add_video_description'=>$postbot_add_video_description
                )
                );
                wp_insert_post( $postbot_insert );
                if( !is_wp_error($postbot_insert) ) {
                    echo postbot_alert('Feed source saved.', 'success');
                    echo '<meta http-equiv="refresh" content="2; URL=\''.admin_url("edit.php?post_type=postbot").'\'" />';
                }
        }
        if($postbot_errors) {
        foreach ($postbot_errors as $postbot_error) {
            echo postbot_alert($postbot_error);
        }
        }
    }
    }
    function postbot_alert ($text, $class = '') {
    return '<div class="postbot-alert '.$class.'">'.$text.'</div>';
    }