<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
die("Hi there! I'm just a plugin, not much I can do when called directly.");
exit();
};
function postbot_post_type() {
 
    $labels = array(
        'name'                => _x( 'PostBot', 'Post Type General Name', 'postbot' ),
        'singular_name'       => _x( 'PostBot', 'Post Type Singular Name', 'postbot' ),
        'menu_name'           => __( 'PostBot', 'postbot' ),
        'parent_item_colon'   => __( 'Parent PostBot', 'postbot' ),
        'all_items'           => __( 'All PostBot', 'postbot' ),
        'view_item'           => __( 'View PostBot', 'postbot' ),
        'add_new_item'        => __( 'Add New Feed Source', 'postbot' ),
       'add_new'             => __( 'Add New', 'postbot' ),
        'edit_item'           => __( 'Edit Feed Source', 'postbot' ),
        'update_item'         => __( 'Update Feed Source', 'postbot' ),
        'search_items'        => __( 'Search Feeds', 'postbot' ),
        'not_found'           => __( 'Not Found', 'postbot' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'postbot' ),
    );
     
    $args = array(
        'label'               => __( 'postbot' ),
        'description'         => __( 'PostBot Auto-blogging.', 'postbot' ),
        'labels'              => $labels,
        'supports'            => array('title', 'custom-fields'),
        'hierarchical'        => false,
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => false,
        'show_in_nav_menus'   => false,
        'show_in_admin_bar'   => false,
        'menu_position'       => 5,
        'can_export'          => false,
        'has_archive'         => false,
        'exclude_from_search' => true,
        'publicly_queryable'  => false,
        'map_meta_cap'        => true,
        'capabilities' => array(
        'create_posts' => 'do_not_allow'
    ),
        'show_in_rest' => false,
    );
    register_post_type( 'postbot', $args );
}
add_action( 'init', 'postbot_post_type', 0 );
