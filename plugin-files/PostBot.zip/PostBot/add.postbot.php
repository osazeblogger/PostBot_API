<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
die("Hi there! I'm just a plugin, not much I can do when called directly.");
exit();
};

$post = array();
$post['post_status']   = 'publish';
$post['post_type']     = 'post';
$post['post_title']    = $post_title;
$post['post_content']  = $post_content;
$post['post_author']   = 1;
$post_id = wp_insert_post( $post );

$image_url = $image_url;
$image_name = sanitize_file_name($post_title) . image_type_to_extension($image_info[2]);
$upload_dir = wp_upload_dir();
$image_data = file_get_contents($image_url);
$unique_file_name = wp_unique_filename( $upload_dir['path'], $image_name );
$filename = basename( $unique_file_name );

if( wp_mkdir_p( $upload_dir['path'] ) ) {
    $file = $upload_dir['path'] . '/' . $filename;
} else {
    $file = $upload_dir['basedir'] . '/' . $filename;
}

file_put_contents( $file, $image_data );

$wp_filetype = wp_check_filetype( $filename, null );

$attachment = array(
    'post_mime_type' => $wp_filetype['type'],
    'post_title'     => sanitize_file_name( $filename ),
    'post_content'   => '',
    'post_status'    => 'inherit'
);

$attach_id = wp_insert_attachment( $attachment, $file, $post_id );

require_once(ABSPATH . 'wp-admin/includes/image.php');

$attach_data = wp_generate_attachment_metadata( $attach_id, $file );

wp_update_attachment_metadata( $attach_id, $attach_data );

set_post_thumbnail( $post_id, $attach_id );

if ( wp_attachment_is_image( $post_id ) ) {
    
$image_title = get_post( $post_id )->post_title;

$image_title = preg_replace( '%\s*[-_\s]+\s*%', ' ',  $image_title );

$image_title = ucwords( strtolower( $image_title ) );

$image_meta = array(
			'ID'		=> $post_id,
			'post_title'	=> $image_title,
			'post_excerpt'	=> $image_title,
			'post_content'	=> $image_title,
		);
		
update_post_meta( $post_id, '_wp_attachment_image_alt', $image_title );

wp_update_post( $image_meta );

}