<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
die("Hi there! I'm just a plugin, not much I can do when called directly.");
exit();
};

add_filter('plugins_api', 'postbot_plugin_info', 20, 3);
function postbot_plugin_info( $res, $action, $args ){
	if( 'plugin_information' !== $action ) {
		return false;
	}

	$plugin_slug = 'PostBot/postbot.php';

	if( $plugin_slug !== $args->slug ) {
		return false;
	}

	if( false == $remote = get_transient( 'postbot_update_' . $plugin_slug ) ) {

		$remote = wp_remote_get( 'https://postbot-api.osaze.media/info.json', array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/json'
			) )
		);

		if ( ! is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && ! empty( $remote['body'] ) ) {
			set_transient( 'postbot_update_' . $plugin_slug, $remote, 43200 );
		}
	
	}

	if( ! is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && ! empty( $remote['body'] ) ) {

		$remote = json_decode( $remote['body'] );
		$res = new stdClass();

		$res->name = $remote->name;
		$res->slug = $plugin_slug;
		$res->version = $remote->version;
		$res->tested = $remote->tested;
		$res->requires = $remote->requires;
		$res->author = '<a href="https://osaze.media">Osaze Media</a>';
		$res->author_profile = 'https://osaze.media';
		$res->download_link = $remote->download_url;
		$res->trunk = $remote->download_url;
		$res->requires_php = '7.3';
		$res->last_updated = $remote->last_updated;
		$res->sections = array(
			'description' => $remote->sections->description,
			'installation' => $remote->sections->installation,
			'changelog' => $remote->sections->changelog
		);

		if( !empty( $remote->sections->screenshots ) ) {
			$res->sections['screenshots'] = $remote->sections->screenshots;
		}

		$res->banners = array(
			'low' => 'https://postbot-api.osaze.media/postbot-img.jpg',
			'high' => 'https://postbot-api.osaze.media/postbot-img.jpg'
		);
		return $res;

	}
}
add_filter('site_transient_update_plugins', 'postbot_push_update' );
 
function postbot_push_update( $transient ){
 
	if ( empty($transient->checked ) ) {
            return $transient;
        }
 
	if( false == $remote = get_transient( 'PostBot/postbot.php' ) ) {
 
		$remote = wp_remote_get( 'https://postbot-api.osaze.media/info.json', array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/json'
			) )
		);
 
		if ( !is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && !empty( $remote['body'] ) ) {
			set_transient( 'PostBot/postbot.php', $remote, 43200 );
		}
 
	}
 
	if( $remote ) {
 
		$remote = json_decode( $remote['body'] );
		
		if( $remote && version_compare( '1.0', $remote->version, '<' ) && version_compare($remote->requires, get_bloginfo('version'), '<' ) ) {
			$res = new stdClass();
			$res->slug = 'PostBot/postbot.php';
			$res->plugin = 'PostBot/postbot.php';
			$res->new_version = $remote->version;
			$res->tested = $remote->tested;
			$res->package = $remote->download_url;
			$transient->response[$res->plugin] = $res;
           	//$transient->checked[$res->plugin] = $remote->version;
           	}
 
	}
        return $transient;
}
add_action( 'upgrader_process_complete', 'postbot_after_update', 10, 2 );
 
function postbot_after_update( $upgrader_object, $options ) {
	if ( $options['action'] == 'update' && $options['type'] === 'plugin' )  {
		delete_transient( 'PostBot/postbot.php' );
	}
}