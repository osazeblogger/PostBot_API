<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
die("Hi there! I'm just a plugin, not much I can do when called directly.");
exit();
};

require_once('vendor/autoload.php');

use andreskrey\Readability\Readability;
use andreskrey\Readability\Configuration;
use andreskrey\Readability\ParseException;

$readability = new Readability(new Configuration());

class PostBot {
    
public function first_img ($content) {
        $matches = array();
        $first_img = false;
        $output = preg_match_all( '/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $content, $matches );
        if ( isset( $matches[1][0] ) ) {
            $first_img = $matches[1][0];
        }
        return $first_img;
    }  
    public function meta_tags ($url) {
        $html = file_get_contents($url);
        libxml_use_internal_errors(true);
        $doc = new DomDocument();
        $doc->loadHTML($html);
        $xpath = new DOMXPath($doc);
        $query = '//*/meta';
        $metas = $xpath->query($query);
        $omtags = array();
        foreach ($metas as $meta) {
            $property = $meta->getAttribute('property');
            $content = $meta->getAttribute('content');
            $omtags[$property] = $content;
        }
        if(empty($omtags)) {
            return false;
        }
        return $omtags;
    }
    public function post_exists_by_slug ( $post_slug ) {
    $post_slug = sanitize_title($post_slug);
    $args_posts = array(
        'post_type'      => 'post',
        'post_status'    => 'any',
        'name'           => $post_slug,
        'posts_per_page' => 1,
    );
    $loop_posts = new WP_Query( $args_posts );
    if ( ! $loop_posts->have_posts() ) {
        return false;
    } else {
        $loop_posts->the_post();
        return $loop_posts->post->ID;
    }
    }
    public function remove_credit ($content) {
        $content = preg_replace('/The post.+appeared first on.+\./ui', '', $content);
        $content = preg_replace("/<p[^>]*>(?:\s|&nbsp;)*<\/p>/", '', $content);
        return $content;
    }
    public function nofollow_all_external_links ($content) {	
	return preg_replace_callback('/<a[^>]+/', array($this, 'add_nofollow_all_external_links'), $content);	
        
    }
    public function add_nofollow_all_external_links ($matches) {
	$link = $matches[0];
	$site_url = get_bloginfo('url');
	if (strpos($link, 'rel') === false) {
	    $link = preg_replace("%(href=\S(?!$site_url))%i", 'rel="nofollow" $1', $link);
	} elseif (preg_match("%href=\S(?!$site_url)%i", $link)) {
	    $link = preg_replace('/rel=\S(?!nofollow)\S*/i', 'rel="nofollow"', $link);
	}
	return $link;
    }
    public function remove_external_url_preg_match ($matches) {
        $site_url = $this->createRegex(get_site_url());
        if (preg_match($site_url, $matches[1])) {
            return '<a href="' . $matches[1] . '" target="_blank">' . $matches[2] . '</a>';
        }
        return $matches[2];
    }
    public function remove_external_links ($content) {
        $pattern = '#<a[^>]*href=[\'"]([^\'"]*)[\'"][^>]*>(((?!<a\s).)*)</a>#i';
        $content = preg_replace_callback($pattern, array($this, 'remove_external_url_preg_match'), $content);
        return $content;
    }
    public function match_rules ($source, $pattern) {
        $pattern = preg_quote($pattern,'/'); 
        $pattern = str_replace( '\*' , '.*', $pattern);
        return preg_match( '/^' . $pattern . '$/i' , $source );
    }
    public function parse_channel_id ($url) {
        $parsed = parse_url(rtrim($url, '/'));
        if (isset($parsed['path']) && preg_match('/^\/channel\/(([^\/])+?)$/', $parsed['path'], $matches)) {
        $channel_url = 'https://www.youtube.com/feeds/videos.xml?channel_id='.$matches[1];
                return $channel_url;
        }
        return false;
}
    public function postbot_get_excerpt ($content, $limit){
    $the_excerpt = ($content ? $content : null);
    $excerpt_length = $limit;
    $the_excerpt = strip_tags(strip_shortcodes($the_excerpt));
    $words = explode(' ', $the_excerpt, $excerpt_length + 1);
    if(count($words) > $excerpt_length) :
        array_pop($words);
        array_push($words, '…');
        $the_excerpt = implode(' ', $words);
    endif;

    return $the_excerpt;
}
    public function fetch_feed ($postbot_array, $postbot_type, $postbot_shortcode) {
        if(!empty($postbot_array['postbot_url']['0'])) {
        $postbot_list = '';
        if(empty($postbot_type)) {
            $postbot_list = '<ul>';
        }
        global $wpdb, $readability;
        $post_content = $post_title = $image_url = '';
        $postbot_feed = file_get_contents($postbot_array['postbot_url']['0']);
        $postbot_feed = str_replace("<content:encoded>","<contentEncoded>", $postbot_feed);
        $postbot_feed = str_replace("</content:encoded>","</contentEncoded>", $postbot_feed);
        $postbot_feed = str_replace("<media:content","<mediacontent", $postbot_feed);
        $postbot_feed = str_replace("</media:content","</mediacontent", $postbot_feed);
        $rss = simplexml_load_string($postbot_feed);
        $x = $rss;
        $allowed_atts = array(
            'align'      => array(),
            'id'         => array(),
            'style'      => array(),
            'src'        => array(),
            'alt'        => array(),
            'href'       => array(),
            'rel'        => array(),
            'rev'        => array(),
            'target'     => array(),
            'width'      => array(),
            'height'     => array(),
            'title'      => array(),
            );
            $allowedposttags['iframe']   = $allowed_atts;
            $allowedposttags['strong']   = $allowed_atts;
            $allowedposttags['small']    = $allowed_atts;
            $allowedposttags['table']    = $allowed_atts;
            $allowedposttags['span']     = $allowed_atts;
            $allowedposttags['abbr']     = $allowed_atts;
            $allowedposttags['code']     = $allowed_atts;
            $allowedposttags['pre']      = $allowed_atts;
            $allowedposttags['div']      = $allowed_atts;
            $allowedposttags['img']      = $allowed_atts;
            $allowedposttags['h1']       = $allowed_atts;
            $allowedposttags['h2']       = $allowed_atts;
            $allowedposttags['h3']       = $allowed_atts;
            $allowedposttags['h4']       = $allowed_atts;
            $allowedposttags['h5']       = $allowed_atts;
            $allowedposttags['h6']       = $allowed_atts;
            $allowedposttags['ol']       = $allowed_atts;
            $allowedposttags['ul']       = $allowed_atts;
            $allowedposttags['li']       = $allowed_atts;
            $allowedposttags['em']       = $allowed_atts;
            $allowedposttags['hr']       = $allowed_atts;
            $allowedposttags['br']       = $allowed_atts;
            $allowedposttags['tr']       = $allowed_atts;
            $allowedposttags['td']       = $allowed_atts;
            $allowedposttags['p']        = $allowed_atts;
            $allowedposttags['a']        = $allowed_atts;
            $allowedposttags['b']        = $allowed_atts;
            $allowedposttags['i']        = $allowed_atts;
            $i = 0;
            foreach($x->channel->item as $entry) {
            $post_title = wp_strip_all_tags($entry->title);
            $postbot_url = esc_url_raw($entry->link);
            if(!empty($postbot_array['postbot_full_content']['0'])) {
                $html = file_get_contents($postbot_url);;
                try {
                $readability->parse($html);
                if(!empty($readability->getContent())) {
                    $post_content = mb_convert_encoding($readability->getContent(),"HTML-ENTITIES", "UTF-8");;
                }
                if(!empty($readability->getImage())) {
                    $image_url = $readability->getImage();
                }
                } catch (ParseException $e) {
            }
            } else {
                $post_content = $entry->description;
            }
            if(!empty($postbot_array['postbot_remove_credits']['0'])) {
               $post_content = $this->remove_credit($post_content);
            }
            if(!empty($postbot_array['postbot_remove_external_links']['0'])) {
                $post_content = $this->remove_external_links($post_content);
            }
            if(!empty($postbot_array['postbot_nofollow']['0'])) {
                $post_content = $this->nofollow_all_external_links($post_content);
            }
            $post_content = wp_kses( $post_content, $allowedposttags );
            $post_category = 1;
            if(!empty($postbot_array['postbot_category_id']['0'])) {
                $post_category = $postbot_array['postbot_category_id']['0'];
            }
            $post_author = 1;
            if(!empty($postbot_array['postbot_author_id']['0'])) {
                $post_author = $postbot_array['postbot_author_id']['0'];
            }
            $pattern = '@((?:https?\:\/\/)(?:[a-zA-Z]{1}(?:[\w\-]+\.)+(?:[\w]{2,5}))';
            $pattern .= '(?:\:[\d]{1,5})?\/(?:[^\s\/]+\/)(?:[^\s]+\.(?:jpe?g|gif|png))(?:\?\w+=\w+(?:&\w+=\w+))?)@';
            if($postbot_type === 'add') {
            if($this->meta_tags($postbot_url) && empty($image_url)) {
                $meta = $this->meta_tags($postbot_url);
                $image_url = $meta['og:image'];
            }
            if(empty($image_url) && preg_match_all($pattern, $entry->mediacontent['url'], $matches)) {
            $image_url = $entry->mediacontent['url'];
            }
            }
            if(!empty($postbot_array['postbot_rules']['0'])) {
            if( $this->match_rules ( $postbot_url, trim($postbot_array['postbot_rules']['0']) ) ) {
                if(!empty($post_title) && !empty($post_content) && !empty($postbot_url)) {
                if($postbot_type === 'add' && filter_var($image_url, FILTER_VALIDATE_URL)) {
                if (!$this->post_exists_by_slug($post_title)  && is_array($image_info = getimagesize($image_url))) {
                require( POSTBOT__PLUGIN_DIR . '/add.postbot.php');
                if(!empty(ctype_digit($postbot_array['postbot_limit']['0']))) {
                    if (++$i == intval($postbot_array['postbot_limit']['0'])) break;
                }  
                }
                } else {
                $postbot_list .= '<li>';
                $postbot_list .= '<a href="'.$postbot_url.'">'.$post_title.'</a>';
                if($postbot_shortcode['show_description'] !== 0) {
                if($postbot_shortcode['description_limit'] === 0) {
                $postbot_shortcode['description_limit'] = 80000000;
                }
                $postbot_list .= '<p>'.$this->postbot_get_excerpt($post_content, $postbot_shortcode['description_limit']).'</p>';
                }
                $postbot_list .= '</li>';
                if(!empty(ctype_digit($postbot_shortcode['limit']['0']))) {
                    if (++$i == intval($postbot_shortcode['limit']['0'])) {
                        echo '</ul>';
                        break;
                    }
                }
                }
                }
            } else {
            
            }
            } else {
                if(!empty($post_title) && !empty($post_content) && !empty($postbot_url)) {
                if($postbot_type === 'add' && filter_var($image_url, FILTER_VALIDATE_URL)) {
                if (!$this->post_exists_by_slug($post_title)  && is_array($image_info = getimagesize($image_url))) {
                require( POSTBOT__PLUGIN_DIR . '/add.postbot.php');
                if(!empty(ctype_digit($postbot_array['postbot_limit']['0']))) {
                    if (++$i == intval($postbot_array['postbot_limit']['0'])) break;
                }  
                }
                } else {
                $postbot_list .= '<li>';
                $postbot_list .= '<a href="'.$postbot_url.'">'.$post_title.'</a>';
                if($postbot_shortcode['show_description'] !== 0) {
                if($postbot_shortcode['description_limit'] === 0) {
                $postbot_shortcode['description_limit'] = 80000000;
                }
                $postbot_list .= '<p>'.$this->postbot_get_excerpt($post_content, $postbot_shortcode['description_limit']).'</p>';
                }
                $postbot_list .= '</li>';
                if(!empty(ctype_digit($postbot_shortcode['limit']['0']))) {
                    if (++$i == intval($postbot_shortcode['limit']['0'])) {
                        echo '</ul>';
                        break;
                    }
                }
                }
                }
            }
        }
            if(empty($postbot_type)) {
                return $postbot_list.'</ul>';
            }
        }
    }
   public function createRegex ($url) {
        $var1 = '#^https?://';
        $host = parse_url($url, PHP_URL_HOST);
        $host_parts = explode('.', $host);
        if (!empty($host_parts)) {
            $length = count($host_parts);
            foreach ($host_parts as $i => $part) {
                if ($i == 0) {
                    if ($part == "www") {
                        $var1 .= '(' . $part . '\\.)?';
                    } else {
                        $var1 .= '' . $part;
                        $var1 .= ($i < ($length - 1)) ? '\\.' : '';
                    }
                } else {
                    $var1 .= '' . $part;
                    $var1 .= ($i < ($length - 1)) ? '\\.' : '';
                }
            }
        }
        $path = '';
        if ((parse_url($url, PHP_URL_PATH) != NULL)) {
            $path = str_replace('/', '\\/', parse_url($url, PHP_URL_PATH));
            $path = str_replace('.', '\\.', $path);
        }
        $var1 .= $path;
        $var1 .= '(/.+)?$#i';
        return $var1;
    }
    public function youtube_fetch_feed ($postbot_array, $postbot_type, $postbot_shortcode) {
        if(!empty($postbot_array['postbot_url']['0'])) {
        $postbot_list = '';
        if(empty($postbot_type)) {
            $postbot_list = '<ul>';
        }
        global $wpdb, $readability;
        $post_content = $postbot_url = $post_title = $image_url = '';
        $feed = file_get_contents($this->parse_channel_id($postbot_array['postbot_url']['0']));
        $feed = str_replace("<media:group>","<mediagroup>", $feed);
        $feed = str_replace("</media:group>","</mediagroup>", $feed);
        $feed = str_replace("<media:thumbnail","<mediathumbnail", $feed);
        $feed = str_replace("</media:thumbnail","</mediathumbnail", $feed);
        $feed = str_replace("<media:description","<mediadescription", $feed);
        $feed = str_replace("</media:description","</mediadescription", $feed);
        $xml = simplexml_load_string($feed, "SimpleXMLElement", LIBXML_NOCDATA);
        $json = json_encode($xml);
        $youtube = json_decode($json, true);
        $limit = $postbot_array['postbot_limit']['0'];
        $allowed_atts = array(
            'align'      => array(),
            'id'         => array(),
            'style'      => array(),
            'src'        => array(),
            'alt'        => array(),
            'href'       => array(),
            'rel'        => array(),
            'rev'        => array(),
            'target'     => array(),
            'width'      => array(),
            'height'     => array(),
            'title'      => array(),
            'frameborder' => array(),
            'allowfullscreen' => array(),
            );
            $allowedposttags['iframe']   = $allowed_atts;
            $allowedposttags['strong']   = $allowed_atts;
            $allowedposttags['small']    = $allowed_atts;
            $allowedposttags['table']    = $allowed_atts;
            $allowedposttags['span']     = $allowed_atts;
            $allowedposttags['abbr']     = $allowed_atts;
            $allowedposttags['code']     = $allowed_atts;
            $allowedposttags['pre']      = $allowed_atts;
            $allowedposttags['div']      = $allowed_atts;
            $allowedposttags['img']      = $allowed_atts;
            $allowedposttags['h1']       = $allowed_atts;
            $allowedposttags['h2']       = $allowed_atts;
            $allowedposttags['h3']       = $allowed_atts;
            $allowedposttags['h4']       = $allowed_atts;
            $allowedposttags['h5']       = $allowed_atts;
            $allowedposttags['h6']       = $allowed_atts;
            $allowedposttags['ol']       = $allowed_atts;
            $allowedposttags['ul']       = $allowed_atts;
            $allowedposttags['li']       = $allowed_atts;
            $allowedposttags['em']       = $allowed_atts;
            $allowedposttags['hr']       = $allowed_atts;
            $allowedposttags['br']       = $allowed_atts;
            $allowedposttags['tr']       = $allowed_atts;
            $allowedposttags['td']       = $allowed_atts;
            $allowedposttags['p']        = $allowed_atts;
            $allowedposttags['a']        = $allowed_atts;
            $allowedposttags['b']        = $allowed_atts;
            $allowedposttags['i']        = $allowed_atts;
            $i = 0;
            foreach ($youtube['entry'] as $k => $v) {
            $post_title = wp_strip_all_tags($v['title']);
            $postbot_url = esc_url_raw($v['link']['@attributes']['href']);
            $videourl = explode("&", $postbot_url);
            if(!empty($v['mediagroup']['mediadescription'])) {
                $post_content = '<p>';
                $post_content .= $videourl[0];
                $post_content .= '</p>';
                if(!empty($postbot_array['postbot_add_video_description']['0'])) {
                    $post_content .= nl2br($v['mediagroup']['mediadescription']);
                }
                $post_content .= '<p><a href="'.$postbot_url.'">Play on Youtube</a></p>';
            }
            if(!empty($v['mediagroup']['mediathumbnail']['@attributes']['url'])) {
                $image_url = $v['mediagroup']['mediathumbnail']['@attributes']['url'];
            }
            if(!empty($postbot_array['postbot_remove_credits']['0']) && !empty($post_content)) {
               $post_content = $this->remove_credit($post_content);
            }
            if(!empty($postbot_array['postbot_remove_external_links']['0']) && !empty($post_content)) {
                $post_content = $this->remove_external_links($post_content);
            }
            if(!empty($postbot_array['postbot_nofollow']['0']) && !empty($post_content)) {
                $post_content = $this->nofollow_all_external_links($post_content);
            }
            $post_content = wp_kses( $post_content, $allowedposttags );
            $post_category = 1;
            if(!empty($postbot_array['postbot_category_id']['0'])) {
                $post_category = $postbot_array['postbot_category_id']['0'];
            }
            $post_author = 1;
            if(!empty($postbot_array['postbot_author_id']['0'])) {
                $post_author = $postbot_array['postbot_author_id']['0'];
            }
            if(!empty($post_title) && !empty($post_content) && !empty($postbot_url)) {
            if($postbot_type === 'add' && filter_var($image_url, FILTER_VALIDATE_URL)) {
            if (!$this->post_exists_by_slug($post_title)  && is_array($image_info = getimagesize($image_url))) {
                require( POSTBOT__PLUGIN_DIR . '/add.postbot.php');
            if(!empty(ctype_digit($limit))) {
                    if (++$i == intval($limit)) break;
                } 
            }
            } else {
            $postbot_list .= '<h2>'.$post_title.'</h2>';
            $postbot_list .= $post_content;
            if(!empty(ctype_digit($limit))) {
                    if (++$i == intval($limit)) break;
                } 
            }
            }
            }
            return $postbot_list;
        }
    }
}
$PostBot = new PostBot();