<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
die("Hi there! I'm just a plugin, not much I can do when called directly.");
exit();
};

function PostBot_shortcode ( $atts ) {
if ( ! is_admin() ) {
global $PostBot;
$Postbot_data = array();
if(empty($atts['id']) || !ctype_digit($atts['id'])) {
    return false;
}
$Postbot_id = $atts['id'];
if ( 'publish' !== get_post_status ( $Postbot_id ) ) {
    return false;
}
$postbot_metas = get_post_meta($Postbot_id, '', true);
$Postbot_data['limit'] = $postbot_metas['postbot_limit']['0'];
if(!empty($atts['limit'])) {
$Postbot_data['limit'] = $atts['limit'];  
}
$Postbot_data['show_video'] = 0;
if(!empty($atts['show_video'])) {
$Postbot_data['show_video'] = $atts['show_video'];
}
$Postbot_data['show_description'] =  0;
if(!empty($atts['show_description'])) {
$Postbot_data['show_description'] = $atts['show_description'];  
}
$Postbot_data['description_limit'] =  0;
if(!empty($atts['description_limit'])) {
$Postbot_data['description_limit'] = $atts['description_limit'];  
}
$url_parsed_arr = parse_url($postbot_metas['postbot_url']['0']);
if ($url_parsed_arr['host'] == "www.youtube.com") {
$postbot_feed_result = $PostBot->youtube_fetch_feed($postbot_metas, '', $Postbot_data);
} else {
$postbot_feed_result = $PostBot->fetch_feed($postbot_metas, '', $Postbot_data);
}
return $postbot_feed_result;
} 
return;
}
add_shortcode( 'postbot', 'PostBot_shortcode' );