<?php

  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
  die('Direct access not allowed');
  exit();
  };
?>
<h2 id="postbot-faq">FAQ</h2>
<div class="postbot-content" data-postbot-content='postbot-rss-url'>
<h3 id="postbot-rss-url">How do I find an RSS feed URL?</h3>
<p>PostBot fetches feed items through RSS feeds. Almost every website in the world provides an RSS feed. Here's how to find it:</p>
<p>Option 1: Add /feed to the website's homepage URL</p>
<p>Many sites have their RSS feed at the same URL. For instance, if the website's URL is www.thiswebsite.com, then the RSS feed could be at www.thiswebsite.com/feed.</p>
<p>Option 2: Look for the RSS share icon</p>
<p>Many websites have share icons on their pages for Facebook, Twitter and more. Many times, there will also be an orange RSS icon. Click on that to access the RSS feed URL.</p>
<p>Option 3: Browser RSS Auto-Discovery</p>
<p>Most browsers either include an RSS auto-discovery tool by default or they allow you to add extensions for it. Firefox shows an RSS icon above the website, in the address bar, which you can click on directly. Chrome offers extensions such as this one.</p>
<p>Option 4: Look at the Page Source</p>
<p>When on any page of the website you're looking to import feed items from, right click and press "View Page Source". Once the new window opens, use the &ldquo;Find&rdquo; feature (Ctrl-F on PC, Command-F on Mac) and search for " RSS". This should take you to a line that reads like this (or similar):</p>
<p><code>&lt;link rel="alternate" type="application/rss+xml" title="RSS Feed" href="https://www.sourcedomain.com/feed/" /&gt;</code></p>
<p>The RSS feed&rsquo;s URL is found between the quotes after href=. In the above case, it would be https://www.sourcedomain.com/feed/.</p>
</div>
<div class="postbot-content" data-postbot-content='postbot-rules'>
<h3 id="postbot-rules">Page Rules Tutorial</h3>
<p>You can use the asterisk (<code>*</code>) in any URL segment to match certain patterns. For example,</p>
<pre>https://example.com/t*st</pre>
<p>Would match:</p>
<pre>https://example.com/test</pre>
<pre>https://example.com/toast</pre>
<pre>https://example.com/trust</pre>
<p><em>https://example.com/foo/*</em>&nbsp;does not match&nbsp;<em>https://</em>example.com/foo. However,&nbsp;<em>https://example.com/foo*</em>&nbsp;does.</p>
</div>
<div class="postbot-content" data-postbot-content='postbot-limit'>
<h3 id="postbot-limit">Limit</h3>
<p>The maximum number of items to import. Enter <code>0</code> for unlimited.</p>
</div>
<div class="postbot-content" data-postbot-content='postbot-url'>
<h3 id="postbot-url">URL</h3>
<p>The URL of the feed source. In most cases, the URL of the site will also work, but for best results we recommend trying to find the URL of the RSS feed.</p>
<p>Also include the <code>http://</code> or <code>https://</code> prefix in the URL.</p>
</div>
<div class="postbot-content" data-postbot-content='postbot-external-url'>
<h3 id="postbot-external-url">Remove External URL</h3>
<p>Remove all external URL's in post content. For example, If your website is <em>example.com</em>, it will remove all URLs to <em>myexample2.com</em>, <em>example2.com</em>, and more.</p>
<p>It will replace the URL as text instead of Hyperlink.</p>
</div>
<div class="postbot-content" data-postbot-content='postbot-credits'>
<h3 id="postbot-credits">Remove Post-credits</h3>
<p>Remove post-credits, for example, "The post&nbsp;<strong>Example Title</strong>&nbsp;appeared first on&nbsp;<strong>Example Blog.</strong>"</p>
</div>
<div class="postbot-content" data-postbot-content='postbot-interval'>
<h3 id="postbot-interval">Update interval</h3>
<p>How frequently the feed source should check for new items and fetch if needed.</p>
</div>
<div class="postbot-content" data-postbot-content='postbot-add-source'>
<h3 id="postbot-add-source">Add Source</h3>
<p>Tick this box to get the site name and URL from the RSS feed, for each item individually.</p>
<p>This option is useful when importing from aggregated RSS feeds that have items from different sources.</p>
<p>If the RSS feed does not provide source information for its items, the name and URL that you have given for the feed source will be used instead.</p>
</div>
<div class="postbot-content" data-postbot-content='postbot-full-content'>
<h3 id="postbot-full-content">Full Content</h3>
<p>Tick the box to get the post's complete content. By default, a WordPress RSS feed displays just the article summary.</p>
</div>
<div class="postbot-content" data-postbot-content='postbot-nofollow'>
<h3 id="postbot-nofollow">Nofollow external URL</h3>
<p>Tick the box to nofollow all links pointing to an external website in the article. This option adds rel="nofollow" to all external links.</p>
</div>
<div class="postbot-content" data-postbot-content='postbot-youtube-channel-id'>
<h3 id="postbot-youtube-channel-id">YouTube Channel ID</h3>
<p>To get a YouTube channel ID, click on any Youtube video and scroll down to the channel name, and right-click and tap copy link address.<br />Example: https://www.youtube.com/channel/UChEYVadfkMCfrKUi6qr3I1Q.</p>
</div>