jQuery(document).ready(function(){
jQuery(".postbot-content").click(function(){
    jQuery(".postbot-content").removeClass('active');
    jQuery(this).addClass('active');
});
jQuery("a[data-postbot-react]").click(function(){
  var postbot_clicked = jQuery(this).attr("href");
  var postbot_link = postbot_clicked.replace("#", "");
  jQuery('.postbot-content[data-postbot-content="'+postbot_link+'"]').trigger('click');
});
});