<?php

  if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
  die('Direct access not allowed');
  exit();
  };

function postbot_cron_schedule ( $schedules ) {
    $schedules['once_every_5_minutes'] = array(
        'interval' => 5*60,
        'display'  => __( 'Once every 5 minutes' ),
    );
    return $schedules;
}
add_filter( 'cron_schedules', 'postbot_cron_schedule' );
if ( ! wp_next_scheduled( 'postbot_cron_hook' ) ) {
    wp_schedule_event( time(), 'once_every_5_minutes', 'postbot_cron_hook' );
}

add_action( 'postbot_cron_hook', 'postbot_cron_function' );

function postbot_cron_function () {
    global $PostBot;
        $postbot_args = array(
            'post_type' => 'postbot',
            'post_status' => 'publish',
            'posts_per_page' => -1,
        ); 
        $postbot_query = new WP_Query( $postbot_args );
        $postbot_posts = $postbot_query->get_posts();
         foreach( $postbot_posts as $post ) {
         $postbot_metas = get_post_meta($post->ID, '', true);
         $postbot_db_updated = $postbot_metas['postbot_updated']['0'];
         $postbot_db_interval = $postbot_metas['postbot_interval']['0'];
         $dbtimestamp = strtotime($postbot_db_updated);
         if (time() - $dbtimestamp > floor($postbot_db_interval/60) * 60) {
            $url_parsed_arr = parse_url($postbot_metas['postbot_url']['0']);
               if ($url_parsed_arr['host'] == "www.youtube.com") {
                   $PostBot->youtube_fetch_feed($postbot_metas, 'add', '');
               } else {
                   $PostBot->fetch_feed($postbot_metas, 'add', '');
               }
               update_post_meta( $post->ID, 'postbot_updated', date( 'Y-m-d H:i:s', time()) );
         }
         }
}