<?php
/**
 * Plugin Name: PostBot
 * Plugin URI: https://osaze.media/
 * Description: PostBot is the most popular and most robust plugin for importing, scraping, and displaying RSS feeds and Atom feeds anywhere on your WordPress website. Add your sources and let the plugin do the leg-work.
 * Version: 1.2
 * Author: Osaze Media
 * Author URI: https://osaze.media
 * Text Domain: PostBot
 */
if ( !function_exists( 'add_action' ) ) {
	echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
	exit;
}
define( 'POSTBOT_VERSION', '1.2' );
define( 'POSTBOT__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
function postbot_menu ()
{
    global $PostBotMenu, $PostBotSubMenu;
       $PostBotMenu = add_menu_page( 'PostBot', 'PostBot', 'manage_options', 'postbot', 'postbot_settings', 'dashicons-superhero', 10);
       $PostBotSubMenu = add_submenu_page( 'postbot', 'Feed Sources', 'Feed Sources', 'manage_options', 'edit.php?post_type=postbot');
}
add_action( 'admin_menu', 'postbot_menu');
require_once(POSTBOT__PLUGIN_DIR . '/class.postbot.php');
require_once(POSTBOT__PLUGIN_DIR . '/register.postbot.php');
require_once(POSTBOT__PLUGIN_DIR . '/settings.postbot.php');
require_once(POSTBOT__PLUGIN_DIR . '/cron.postbot.php');
require_once(POSTBOT__PLUGIN_DIR . '/shortcode.postbot.php');
require_once(POSTBOT__PLUGIN_DIR . '/update.postbot.php');