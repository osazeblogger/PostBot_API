<?php

function postbot_plugin_info( $res, $action, $args ) {

    if ($action !== 'plugin_information') {
        return false;
    }
    
    if ('PostBot/postbot.php' !== $args->slug) {
        return $res;
    }

    if (false == $remote = get_transient( 'postbot_upgrade_pluginslug' )) {

        $remote = wp_remote_get( 'https://postbot-api.osaze.media/info.json', array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json'
            ))
        );

        if (!is_wp_error( $remote ) && isset( $remote[ 'response' ][ 'code' ] ) && $remote[ 'response' ][ 'code' ] == 200 && !empty( $remote[ 'body' ] )) {
            set_transient( 'postbot_upgrade_pluginslug', $remote, 21600 ); // 6 hours cache
        }
    }

    if (!is_wp_error( $remote )) {

        $remote = json_decode( $remote[ 'body' ] );

        $res = new stdClass();
        $res->name = $remote->name;
        $res->slug = $remote->slug;
        $res->version = $remote->version;
        $res->tested = $remote->tested;
        $res->requires = $remote->requires;
        $res->author = $remote->author;
        $res->author_profile = $remote->author_homepage;
        $res->download_link = $remote->download_link;
        $res->trunk = $remote->download_link;
        $res->last_updated = $remote->last_updated;
        $res->sections = array(
            'description' => $remote->sections->description,
            'installation' => $remote->sections->installation,
        );
        $res->banners = array(
            'low' => $remote->banners->low,
            'high' => $remote->banners->high,
        );

        return $res;
    }

    return false;

}

add_filter( 'plugins_api', 'postbot_plugin_info', 20, 3 );

function postbot_push_update( $transient ) {

    if (empty( $transient->checked )) {
        return $transient;
    }

    if (false == $remote = get_transient( 'postbot_upgrade_pluginslug' )) {
        
        $remote = wp_remote_get( 'https://postbot-api.osaze.media/info.json', array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json'
            ))
        );

        if (!is_wp_error( $remote ) && isset( $remote[ 'response' ][ 'code' ] ) && $remote[ 'response' ][ 'code' ] == 200 && !empty( $remote[ 'body' ] )) {
            set_transient( 'postbot_upgrade_pluginslug', $remote, 21600 );
        }
    }

    if ($remote) {

        $remote = json_decode( $remote[ 'body' ] );
        
        if ($remote && version_compare( POSTBOT_VERSION, $remote->version, '<' ) && version_compare( $remote->requires, get_bloginfo( 'version' ), '<' )) {
            $res = new stdClass();
            $res->slug = 'PostBot';
            $res->plugin = 'PostBot/postbot.php';
            $res->new_version = $remote->version;
            $res->tested = $remote->tested;
            $res->package = $remote->download_link;
            $transient->response[ $res->plugin ] = $res;
        }
    }
    return $transient;

}

add_filter( 'site_transient_update_plugins', 'postbot_push_update' );

function postbot_after_update( $upgrader_object, $options ) {
    if ($options[ 'action' ] == 'update' && $options[ 'type' ] === 'plugin') {

        delete_transient( 'postbot_upgrade_pluginslug' );
    }

}

add_action( 'upgrader_process_complete', 'postbot_after_update', 10, 2 );